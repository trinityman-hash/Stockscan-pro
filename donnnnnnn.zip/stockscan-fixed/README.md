# StockScan Pro — Vercel API Server

## ✅ Fixed: Node.js 18.x → 20.x (Vercel compatible)

---

## 🚀 Step 1: Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) → **Add New Project**
2. Upload this folder (or push to GitHub and import)
3. In **Environment Variables**, add:
   - Key: `FINNHUB_API_KEY`
   - Value: your Finnhub API key from [finnhub.io](https://finnhub.io)
4. Click **Deploy**

After deploy, your API URLs will be:
- `https://YOUR-PROJECT.vercel.app/api/prices?symbol=RELIANCE`
- `https://YOUR-PROJECT.vercel.app/api/ticker`

---

## 🌐 Step 2: Connect to Blogger

In your Blogger HTML/JS code, replace any local API calls with your Vercel URL:

```javascript
// Replace with your actual Vercel project URL
const API_BASE = "https://YOUR-PROJECT.vercel.app";

// Fetch a stock quote
fetch(`${API_BASE}/api/prices?symbol=RELIANCE`)
  .then(r => r.json())
  .then(data => console.log(data));

// Fetch ticker bar data
fetch(`${API_BASE}/api/ticker`)
  .then(r => r.json())
  .then(data => console.log(data));
```

In Blogger:
1. Go to **Theme → Edit HTML**
2. Paste your StockScan widget HTML before `</body>`
3. Set `API_BASE` to your Vercel URL

---

## 📁 File Structure

```
stockscan-vercel/
├── api/
│   ├── prices.js   ← Quote + candle data endpoint
│   └── ticker.js   ← Batch ticker bar endpoint
├── vercel.json     ← Vercel config (Node 20.x)
├── package.json    ← Node 20.x engine
└── README.md
```
